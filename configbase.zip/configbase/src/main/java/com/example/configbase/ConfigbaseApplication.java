package com.example.configbase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConfigbaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConfigbaseApplication.class, args);
	}

}
