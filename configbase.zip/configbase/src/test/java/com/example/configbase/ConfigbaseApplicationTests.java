package com.example.configbase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigbaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
